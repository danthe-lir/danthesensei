
let grafico;

async function carregarDados(){

  const resposta = await fetch('http://localhost:3000/presencas');
  const dados = await resposta.json();

  document.getElementById('total').innerText = dados.length;

  if(dados.length > 0){
    document.getElementById('ultima').innerText =
    dados[dados.length - 1].data_hora;
  }

  carregarTabela(dados);
  carregarGrafico(dados);
}

function carregarTabela(dados){

  const tabela = document.getElementById('tabela');

  tabela.innerHTML = '';

  dados.reverse().forEach(item => {

    tabela.innerHTML += `
      <tr>
        <td>${item.id}</td>
        <td>${item.data_hora}</td>
        <td>${item.status}</td>
      </tr>
    `;
  });
}

function carregarGrafico(dados){

  const horas = {};

  dados.forEach(item => {

    const hora = item.data_hora.split(' ')[1].split(':')[0];

    horas[hora] = (horas[hora] || 0) + 1;

  });

  const ctx = document.getElementById('grafico');

  if(grafico){
    grafico.destroy();
  }

  grafico = new Chart(ctx, {

    type:'line',

    data:{
      labels:Object.keys(horas),

      datasets:[{
        label:'Movimentações',
        data:Object.values(horas),
        borderWidth:3,
        tension:0.4
      }]
    }
  });
}

carregarDados();

setInterval(carregarDados,3000);
