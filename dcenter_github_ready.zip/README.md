# D'CENTER - Dashboard IoT

## Projeto

Sistema de monitoramento de presença utilizando:
- Arduino
- Sensor PIR HC-SR501
- JSON Server
- Dashboard Web

## Tecnologias
- HTML5
- CSS3
- JavaScript
- Chart.js
- JSON Server

## Como executar

### Instalar JSON Server

```bash
npm install -g json-server
```

### Rodar API

```bash
json-server --watch db.json
```

### Abrir dashboard

Abra:
index.html

## API

http://localhost:3000/presencas
